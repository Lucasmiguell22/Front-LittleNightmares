<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../lojinha/css/style.css">
    <title>You and I</title>
</head>
<nav>
            <ul>
                <li><a href="produtos.php">Home</a></li>
                <li><a href="#">Shopping cart</a></li>
                <li><a href="#">My account</a></li>
                <li><a href="about.php">About me</a></li>
                <li><a href="index.php">Logout</a></li>
            </ul>
        </nav>
<header> 
    <h2> "Little" about me!</h2>
    
</header>
<body>
    <div class="indexx">
        <img src="imagens/index.png">
    </div>
    <h4>Hello, my name is Lucas, I'm a programming student, and this is my first real job, I hope you like it, I made it based on a game that I love.<br>I hope to enter this area that I want so much, the path is difficult but rewarding.</h4>
        <div id="container">

    <footer>
        <div id="redes">
            <ul>
                <li><a href="https://facebook.com"><img src="imagens/facebook.png"> Facebook</a></li>
                <li><a href="https://instagram.com"><img src="imagens/insta.png"> Instagram</a></li>
                <li><a href="https://tiktok.com"><img src="imagens/tiktok.png"> TikTok</a></li>
                <li><a href="https://whatsapp.com"><img src="imagens/whatsapp.png"> WhatsApp</a></li>
            </ul>
        </div>
        <address>
            Little Nightmares - "Bocarra"
        </address>
    </footer>  
</div>
</body>
</html>