<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../lojinha/css/style.css">
    <title>You and I</title>
</head>
<header>
     
    <h2> Oh so it's you, have fun haha!</h2>
    <nav>
            <ul>
                <li><a href="produtos.php">Home</a></li>
                <li><a href="#">Shopping cart</a></li>
                <li><a href="#">My account</a></li>
                <li><a href="about.php">About me</a></li>
                <li><a href="index.php">Logout</a></li>
            </ul>
        </nav>

    <main>
            <h2>items</h2>
            <section id="lancamentos">
                <div class="card-lanterna">
                <img src="imagens/pocao-removebg-preview.png" alt="Poção"></a>
                    <h3>Running potion</h3>
                    <p>a potion that will help you escape.</p>
                    <span class="preco">$$ 249,90</span>
                </div>
  
                
            </section>
        </main>
        <button class="buttom-lanterna"><a href="#">Buy</button></a>
        <footer>
            <div id="redes">
                <ul>
                    <li><a href="https://facebook.com"><img src="imagens/facebook.png"> Facebook</a></li>
                    <li><a href="https://instagram.com"><img src="imagens/insta.png"> Instagram</a></li>
                    <li><a href="https://tiktok.com"><img src="imagens/tiktok.png"> TikTok</a></li>
                    <li><a href="https://whatsapp.com"><img src="imagens/whatsapp.png"> WhatsApp</a></li>
                </ul>
            </div>
            <address>
                Little Nightmares - "Bocarra"
            </address>
        </footer>
    </body>
</html>