<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../lojinha/css/style.css">
    <title>You and I</title>
</head>
<header> 
    <h2> Do you already have an account? Or are you trying to trick me?</h2>
</header>
<body>
<form action="#" method="POST">
        <div>
            <label for="id">Username:</label>
            <input type="email" id="email" name="email">
        </div>
        <div>
            <label for="senha">Password:</label>
            <input type="password" id="senha" name="senha">
        </div>
        <div>
            <button class="buttom"><a href="produtos.php">Login</button></a>
        </div>
    </form>
    </div>

    <footer>
            <div id="redes">
                <ul>
                    <li><a href="https://facebook.com"><img src="imagens/facebook.png"> Facebook</a></li>
                    <li><a href="https://instagram.com"><img src="imagens/insta.png"> Instagram</a></li>
                    <li><a href="https://tiktok.com"><img src="imagens/tiktok.png"> TikTok</a></li>
                    <li><a href="https://whatsapp.com"><img src="imagens/whatsapp.png"> WhatsApp</a></li>
                </ul>
            </div>
            <address>
                Little Nightmares - "Bocarra"
            </address>
        </footer>
    
</body>
</html>