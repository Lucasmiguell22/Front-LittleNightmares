<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../lojinha/css/style.css">
    <title>You and I</title>
</head>
<header> 
    <h2> WELCOME RUNAWAY KID!</h2>
</header>
<body>
    <div class="indexx">
        <img src="imagens/index.png">
    </div>
        <div id="container">
    <button class="button"><a href="header.php">Enter</button></a>
    <footer>
        <div id="redes">
            <ul>
                <li><a href="https://facebook.com"><img src="imagens/facebook.png"> Facebook</a></li>
                <li><a href="https://instagram.com"><img src="imagens/insta.png"> Instagram</a></li>
                <li><a href="https://tiktok.com"><img src="imagens/tiktok.png"> TikTok</a></li>
                <li><a href="https://whatsapp.com"><img src="imagens/whatsapp.png"> WhatsApp</a></li>
            </ul>
        </div>
        <address>
            Little Nightmares - "Bocarra"
        </address>
    </footer>  
</div>
</body>
</html>